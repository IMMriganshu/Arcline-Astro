export interface SiteConfig {
  name: string;
  title: string;
  description: string;
  email: string;
  phone: string;
  address: string;
  estYear: string;
  ogImage?: string;
  analyticsId?: string;
  vercelDeployHookUrl?: string;
  headerCtaText?: string;
  headerCtaLink?: string;
}

export interface HeroContent {
  eyebrowTag: string;
  titleLine1: string;
  titleLine2: string;
  headline: string;
  subheadline: string;
  primaryCtaText: string;
  primaryCtaLink: string;
  secondaryCtaText: string;
  secondaryCtaLink: string;
  titleVideoUrl: string;
  bannerVideoUrl: string;
  bannerPosterUrl: string;
}

export interface NavItem {
  id: string;
  label: string;
  href: string;
  hasDropdown?: boolean;
}

export interface Service {
  id: string;
  number: string;
  title: string;
  description: string;
  image: string;
  imageAlt: string;
}

export interface Project {
  id: string;
  number: string;
  title: string;
  category: string;
  image: string;
  description: string;
  year: string;
  location: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  avatar: string;
  rating: number;
}

export interface Article {
  id: string;
  slug: string;
  category: string;
  date: string;
  readTime: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  published: boolean;
}

export interface ComparisonItem {
  id: string;
  metric: string;
  rentedClicks: string;
  organicAuthority: string;
}

export interface FooterContent {
  tagline?: string;
  description?: string;
  copyrightText: string;
  badge: string;
  disclaimer: string;
}

export interface MediaAsset {
  id: string;
  name: string;
  url: string;
  type: 'image' | 'video';
  size?: string;
}

export interface AboutMilestone {
  yearBudget: string;
  text: string;
}

export interface AboutContent {
  badge: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  timelineTitle: string;
  timelineSubtitle: string;
  milestones: AboutMilestone[];
}

export interface VideoShowcaseContent {
  videoUrl: string;
  titleVideoUrl: string;
  posterUrl: string;
}

export interface ProjectCtaContent {
  badge: string;
  headline: string;
  description: string;
  buttonText: string;
  buttonLink: string;
  backgroundImage: string;
}

export interface PageSectionItem {
  id: string;
  name: string;
  type: string;
  badge?: string;
  title?: string;
  subtitle?: string;
  body?: string;
  image?: string;
  videoUrl?: string;
  primaryCtaText?: string;
  primaryCtaLink?: string;
  secondaryCtaText?: string;
  secondaryCtaLink?: string;
  customHtml?: string;
  items?: any[];
}

export interface Page {
  id: string;
  slug: string;
  title: string;
  content: string; // HTML/Markdown
  sections?: PageSectionItem[];
}

export interface CmsData {
  siteConfig: SiteConfig;
  hero: HeroContent;
  navigation: NavItem[];
  services: Service[];
  projects: Project[];
  testimonials: Testimonial[];
  articles: Article[];
  pages: Page[];
  comparison: ComparisonItem[];
  footer: FooterContent;
  media: MediaAsset[];
  aboutContent?: AboutContent;
  projectCta?: ProjectCtaContent;
  videoShowcase?: VideoShowcaseContent;
  lastPublishedAt?: string;
  version: number;
}
